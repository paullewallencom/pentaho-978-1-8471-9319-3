public class LibraryInfo {
	private String name;
	private String description;
	private long size;
	public LibraryInfo() {}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	public void setSize(long size) {
		this.size = size;
	}
	public long getSize() {
		return size;
	}
}
